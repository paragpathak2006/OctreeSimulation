

classdef Node_2D < handle
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        m_bbox;
        m_ChildNodes;
        m_PMC;

        m_PointA;
        m_PointB;
        m_PointC;
        m_PointD;
        
        m_PointE; 
        m_PointF;
        m_PointG;
        m_PointH;
        
        m_cellType;
        m_ImplicitFn;
        m_Integral;
        m_Error;
        m_SmallFeatureList;
        P;
%         p;



        numTri;
    end
    
    methods
        function obj = Node_2D( PMC, implicitFn, PointA, PointB, PointC, PointD, PointE, PointF, PointG, PointH)

            obj.m_PMC = PMC;
            obj.m_ImplicitFn = implicitFn;

            obj.m_PointA = PointA;
            obj.m_PointB = PointB;
            obj.m_PointC = PointC;
            obj.m_PointD = PointD;

            obj.m_PointE = PointE; 
            obj.m_PointF = PointF;
            obj.m_PointG = PointG;
            obj.m_PointH = PointH;
            
%             obj.p = zeros(28);
            obj.P = zeros(28,3);
            
            obj.Classify();
            obj.m_bbox = [obj.m_PointA';obj.m_PointG'];
        end
        
%         function Corners = GetCornerPts( obj )
%             Corners = [obj.m_PointA'; obj.m_PointB'; obj.m_PointC'; obj.m_PointD';];
%         end
%         
%         function [] = AddSmallFeatureList( obj, SmallFeatureList )
%             obj.m_SmallFeatureList = SmallFeatureList;
%         end
        
        function type = GetCellType( obj )
            type = obj.m_cellType;
        end
        
        function flag = IsBoundary( obj )
            if( obj.m_cellType == 0 || obj.m_cellType == 255 )
            flag = false;
            else
                flag = true;
            end
        end
        
        function flag = IsInterior( obj ) 
            if( obj.m_cellType == 255 )
                flag = true;

            else
                flag = false;
            end
        end
        
        function flag = IsOuter( obj ) 
            if( obj.m_cellType == 0 )
                flag = true;
            else
                flag = false;
            end
        end
        
%Begin 1---------------------------------------------------------
        function Partition( obj, depth )
            
            if( depth > 0 )
                obj.Partition_One_Node();
                for i = 1 : 8
                    if( obj.m_ChildNodes(i).IsBoundary() )
                        obj.m_ChildNodes(i).Partition( depth -1 );
                    end
                end
            end
        end
        
        function GetLeafNodes( obj, nodeList )
            
            if( isempty( obj.m_ChildNodes ) )
                nodeList.Add(obj);
                return;
            else
                for i = 1 : 8 
                    obj.m_ChildNodes(i).GetLeafNodes( nodeList );
                end
            end
        end
        
%Begin 2--------------------------------------------------------
        function Partition_One_Node( obj )


PointAB = 1.0*(obj.m_PointA + obj.m_PointB)/2.0;
PointBC = 1.0*(obj.m_PointB + obj.m_PointC)/2.0;
PointCD = 1.0*(obj.m_PointC + obj.m_PointD)/2.0;
PointAD = 1.0*(obj.m_PointD + obj.m_PointA)/2.0;

PointEF = 1.0*(obj.m_PointE +obj.m_PointF)/2.0;
PointFG = 1.0*(obj.m_PointF +obj.m_PointG)/2.0;
PointGH = 1.0*(obj.m_PointG +obj.m_PointH)/2.0;
PointEH = 1.0*(obj.m_PointH +obj.m_PointE)/2.0;

PointAE = 1.0*(obj.m_PointA +obj.m_PointE)/2.0;
PointBF = 1.0*(obj.m_PointB +obj.m_PointF)/2.0;
PointCG = 1.0*(obj.m_PointC +obj.m_PointG)/2.0;
PointDH = 1.0*(obj.m_PointD +obj.m_PointH)/2.0;

PointABCD = (PointAB +PointCD)/2;
PointEFGH = (PointEF +PointGH)/2;

PointABEF = (PointAB +PointEF)/2;
PointCDGH = (PointCD +PointGH)/2;

PointADEH = (PointAD +PointEH)/2;
PointBCFG = (PointBC +PointFG)/2;

PointCET = (PointABCD +PointEFGH)/2;

%-----------------------------
Node1 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, obj.m_PointA,PointAB,PointABCD,PointAD,PointAE,PointABEF,PointCET,PointADEH);
Node2 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointAB,obj.m_PointB,PointBC,PointABCD,PointABEF,PointBF,PointBCFG,PointCET);
Node3 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointABCD,PointBC,obj.m_PointC,PointCD,PointCET,PointBCFG,PointCG,PointCDGH);
Node4 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointAD,PointABCD,PointCD,obj.m_PointD,PointADEH,PointCET,PointCDGH,PointDH);
%-----------------------------
Node5 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointAE,PointABEF,PointCET,PointADEH,obj.m_PointE,PointEF,PointEFGH,PointEH);
Node6 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointABEF,PointBF,PointBCFG,PointCET,PointEF,obj.m_PointF,PointFG,PointEFGH);
Node7 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointCET,PointBCFG,PointCG,PointCDGH,PointEFGH,PointFG,obj.m_PointG,PointGH);
Node8 = Node_2D( obj.m_PMC,obj.m_ImplicitFn, PointADEH,PointCET,PointCDGH,PointDH,PointEH,PointEFGH,PointGH,obj.m_PointH);

            obj.m_ChildNodes = [Node1; Node2; Node3; Node4;Node5; Node6; Node7; Node8];
        end
        
%Begin 3--------------------------------------------------------
        function cellType = Classify( obj )
%              f1 = obj.m_PMC(obj.m_PointA(1),obj.m_PointA(2),obj.m_PointA(3));
%              f2 = bitsll(obj.m_PMC(obj.m_PointB(1),obj.m_PointB(2),obj.m_PointB(3)),1);
%              f3 = bitsll(obj.m_PMC(obj.m_PointC(1), obj.m_PointC(2),obj.m_PointC(3)),2);
%              f4 = bitsll(obj.m_PMC(obj.m_PointD(1),obj.m_PointD(2),obj.m_PointD(3) ),3);
% 
%              f5 = bitsll(obj.m_PMC(obj.m_PointE(1),obj.m_PointE(2) ,obj.m_PointE(3)),4);
%              f6 = bitsll(obj.m_PMC(obj.m_PointF(1),obj.m_PointF(2),obj.m_PointF(3) ),5);
%              f7 = bitsll(obj.m_PMC(obj.m_PointG(1),obj.m_PointG(2) ,obj.m_PointG(3)),6);
%              f8 = bitsll(obj.m_PMC(obj.m_PointH(1),obj.m_PointH(2) ,obj.m_PointH(3)),7);
% 
%              f12 = bitor(f1,f2,'uint8');
%              f34 = bitor(f3,f4,'uint8');
%             
%             cellType = bitor(f12,f34,'uint8');

              f1 = obj.m_PMC(obj.m_PointA(1),obj.m_PointA(2),obj.m_PointA(3));
              f2 = obj.m_PMC(obj.m_PointB(1),obj.m_PointB(2),obj.m_PointB(3))*2;
              f3 = obj.m_PMC(obj.m_PointC(1), obj.m_PointC(2),obj.m_PointC(3))*4;
              f4 = obj.m_PMC(obj.m_PointD(1),obj.m_PointD(2),obj.m_PointD(3))*8;
 
              f5 = obj.m_PMC(obj.m_PointE(1),obj.m_PointE(2) ,obj.m_PointE(3))*16;
              f6 = obj.m_PMC(obj.m_PointF(1),obj.m_PointF(2),obj.m_PointF(3))*32;
              f7 = obj.m_PMC(obj.m_PointG(1),obj.m_PointG(2) ,obj.m_PointG(3))*64;
              f8 = obj.m_PMC(obj.m_PointH(1),obj.m_PointH(2) ,obj.m_PointH(3))*128;

             obj.m_cellType = f1 + f2 + f3 + f4 + f5 + f6 +f7 + f8;
%             obj.numTri = Cube(cellType+1,1);
%             obj.p(1) = obj.numTri ;
%             for i = 2 : obj.numTri*3 + 1
%                 obj.p(i) = Cube(cellType+1,i);
%             end
            end    
        
        function Pts = Intersection(obj, ptA, ptB )
            ax = ptA(1);            ay = ptA(2);            az = ptA(3);

            d = ptB - ptA;
            dx = d(1);            dy = d(2);            dz = d(3);
            
            fun = @(t) obj.m_ImplicitFn( ax + t*dx , ay + t*dy , az + t*dz );

%             f1 = abs(fun(0));
%             f2 = abs(fun(1));
            
            %t0 = f1/(f1 + f2);
            t0 = 0.5;
            t = fsolve(fun,t0);
            %fMin = @(t) fun(t0).*fun(t0);
            %t = fminsearch(fMin,0);
            if( t >= 0 )
                Pts = [ax + t*dx; ay + t*dy;az + t*dz ];
            else
                Pts = ptA';
            end
        end
        
        function Polygonise( obj)
        global Cube;
        Type=obj.m_cellType;
            for i = 1:12
                switch(i)
                    case 1
%                         Cube(Type*5+1 ,i)
                        
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)= obj.Intersection(obj.m_PointA,obj.m_PointB);end 
                    case 2
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:) = obj.Intersection(obj.m_PointB,obj.m_PointC); end 
                    case 3
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointC,obj.m_PointD); end 
                    case 4
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointA,obj.m_PointD); end 
                    case 5
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointE,obj.m_PointF); end 
                    case 6
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointF,obj.m_PointG); end 
                    case 7
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointG,obj.m_PointH); end 
                    case 8
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointE,obj.m_PointH); end 
                    case 9
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointA,obj.m_PointE); end 
                    case 10
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointB,obj.m_PointF); end 
                    case 11
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointC,obj.m_PointG); end 
                    case 12
%                         Cube(Type*5+1 ,i)
                        if(Cube(Type*5+1 ,i)) obj.P(i,:)  = obj.Intersection(obj.m_PointD,obj.m_PointH); end 
                end
            end
            
            obj.P(21,:)  = obj.m_PointA ;
            obj.P(22,:)  = obj.m_PointB ;
            obj.P(23,:)  = obj.m_PointC ;
            obj.P(24,:)  = obj.m_PointD ;

            obj.P(25,:)  = obj.m_PointE ; 
            obj.P(26,:)  = obj.m_PointF ;
            obj.P(27,:)  = obj.m_PointG ;
            obj.P(28,:)  = obj.m_PointH ;

        end
        
%         function Bbox = GetBoundingBox( obj, XYPolygon )
%             Xmin = min(XYPolygon(:,1));
%             Ymin = min(XYPolygon(:,2));
%             Xmax = max(XYPolygon(:,1));
%             Ymax = max(XYPolygon(:,2));
%             
%             Bbox = [ Xmin Ymin; Xmax Ymax];
%         end
        
        
        
%Begin 4--------------------------------------------------------
        
%         function [ApproxPolygon, ComputeSSATerm] = GetApproximatePolygon( obj )
%             ApproxPolygon = [];
%             ComputeSSATerm = [];
%             switch( obj.GetCellType() )
%                 case 0
%                     %Outer Node
%                 case 1
%                     %Interior Node
%                     ApproxPolygon = zeros( 4, 2);
%                     ComputeSSATerm = zeros( 4, 1);
%                     ApproxPolygon(1,:) = obj.m_PointA';
%                     ApproxPolygon(2,:) = obj.InterpolateZeroLevelSet( obj.m_PointA, obj.m_PointB );
%                     ApproxPolygon(3,:) = obj.InterpolateZeroLevelSet( obj.m_PointA, obj.m_PointD ); 
%                     ApproxPolygon(4,:) = ApproxPolygon(1,:);
%                     ComputeSSATerm(2) = 1;
%             end
%         end
%         
% %Begin 5--------------------------------------------------------
%         function Pts = InterpolateZeroLevelSet( obj, ptA, ptB )
%             ax = ptA(1);
%             ay = ptA(2);
%             d = ptB - ptA;
%             dx = d(1);
%             dy = d(2);
%             fun = @(t) obj.m_ImplicitFn( ax + t*dx , ay + t*dy );
%             f1 = abs(fun(0));
%             f2 = abs(fun(1));
%             
%             %t0 = f1/(f1 + f2);
%             t0 = 0.5;
%             t = fsolve(fun,t0);
%             %fMin = @(t) fun(t0).*fun(t0);
%             %t = fminsearch(fMin,0);
%             if( t >= 0 )
%                 Pts = [ax + t*dx; ay + t*dy];
%             else
%                 Pts = ptA';
%             end
%         end
%         
        function Draw( obj, color )

%              if(isempty(obj.m_ChildNodes) && IsInterior(obj))
%                if(isempty(obj.m_ChildNodes) && IsOuter(obj))
            if(isempty(obj.m_ChildNodes) && IsBoundary(obj))
                obj.Draw_One_Node( color );
            end

            if(~isempty(obj.m_ChildNodes) )
                for i = 1: 8
                    obj.m_ChildNodes(i).Draw(color);
                end
            end
        end
%         function Draw_One_Node(obj, color)
%             diff = (obj.m_PointC - obj.m_PointA);
%             w = abs(diff(1));
%             h = abs(diff(2));
%             hold on;
%             %rectangle('Position',[obj.m_PointA(1),obj.m_PointB(2),w,h],'EdgeColor',color);
%             p1 = obj.m_PointA;
%             p2 = obj.m_PointB;
%             p3 = obj.m_PointC;
%             p4 = obj.m_PointD;
%             p5 = p1;
% 
%             p6 = obj.m_PointE;
%             p7 = obj.m_PointF;
%             p8 = obj.m_PointG;
%             p9 = obj.m_PointH;
%             p10 = p6;
% 
%             A1=p1(1)>=0;A2=p2(1)>=0;A3=p3(1)>=0;A4=p4(1)>=0;A5=p5(1)>=0;A6=p6(1)>=0;A7=p7(1)>=0;A8=p8(1)>=0;
%             B1=p1(2)>=0;B2=p2(2)>=0;B3=p3(2)>=0;B4=p4(2)>=0;B5=p5(2)>=0;B6=p6(2)>=0;B7=p7(2)>=0;B8=p8(2)>=0;
%             C1=p1(3)>=0;C2=p2(3)>=0;C3=p3(3)>=0;C4=p4(3)>=0;C5=p5(3)>=0;C6=p6(3)>=0;C7=p7(3)>=0;C8=p8(3)>=0;
% 
%             D1=A1&&A2&&A3&&A4&&A5&&A6&&A7&&A8;
%             E1=B1&&B2&&B3&&B4&&B5&&B6&&B7&&B8;
%             F1=C1&&C2&&C3&&C4&&C5&&C6&&C7&&C8;
% 
%             if(D1&&E1&&F1)
%               p = [p1';p2';p3';p4';p5';p6';p7';p8';p9';p10'];
% %             line(p(:,1),p(:,2),p(:,3),'Color',color);
%               plot3(p(:,1),p(:,2),p(:,3),'Color',color);
%             end
%              hold off;
%         end
%     end
    
%         function Draw_One_Node(obj, color)
%             
% % if(obj.m_PointA(1)+obj.m_PointG(1)<0) return;end
% % if(obj.m_PointA(2)+obj.m_PointG(2)<0) return;end
% % if(obj.m_PointA(3)+obj.m_PointG(3)<0) return;end
%             Polygonise( obj);
% 
%             hold on
%             
%             p1 = obj.m_PointA;
%             p2 = obj.m_PointB;
%             p3 = obj.m_PointC;
%             p4 = obj.m_PointD;
%             p5 = p1;
% 
%             p6 = obj.m_PointE;
%             p7 = obj.m_PointF;
%             p8 = obj.m_PointG;
%             p9 = obj.m_PointH;
%             p10 = p6;
% 
% %               p = [p1';p2';p3';p4';p5';p6';p7';p8';p9';p10'];
% %             line(p(:,1),p(:,2),p(:,3),'Color',color);
% %               plot3(p(:,1),p(:,2),p(:,3),'Color',color);
%             
%             for i=0:obj.p(1)-1
%                 P1 = [obj.P(3*i+2,:)',obj.P(3*i+3,:)',obj.P(3*i+4,:)',obj.P(3*i+2,:)'];
% %               line(p(:,1),p(:,2),p(:,3),'Color',color);
%                 plot3(P1(1,:),P1(2,:),P1(3,:),'Color',color);
% %                 plot3(P1(:,1),P1(:,2),P1(:,3),'Color',color);
%             end
%              hold off;
%         end
%     end
    
        function Draw_One_Node(obj, color)
        global Cube;            
         if(obj.m_PointA(1)+obj.m_PointG(1)<0) return;end
         if(obj.m_PointA(2)+obj.m_PointG(2)<0) return;end
         if(obj.m_PointA(3)+obj.m_PointG(3)<0) return;end
            Polygonise( obj);

            hold on
            Type = obj.m_cellType;
            numSolid = Cube( Type*5+1 ,14);

             for i = 1 : numSolid-1
%                  if(Cube( Type*5+1 ,13 )==0) i = numSolid;end % outer
                 if(Cube( Type*5+1 ,13 )==1) i = numSolid;end % inner
%                 i=1;    
                numFace =   Cube( Type*5+i ,15);
                 for j = 0 : numFace-1 
                    numP =   Cube( Type*5+i ,16+j*7);
                       if(numP>6||numP<3) 
                           numP
                       end
                   switch( numP)
                    case 3
                    p1 =   Cube( Type*5+i ,16+j*7+1);
                    p2 =   Cube( Type*5+i ,16+j*7+2);
                    p3 =   Cube( Type*5+i ,16+j*7+3);
                    P3 = [obj.P(p1,:)',obj.P(p2,:)',obj.P(p3,:)',obj.P(p1,:)'];
                      plot3(P3(1,:),P3(2,:),P3(3,:),'Color',color);

                    case 4
                    p1 =   Cube( Type*5+i ,16+j*7+1);
                    p2 =   Cube( Type*5+i ,16+j*7+2);
                    p3 =   Cube( Type*5+i ,16+j*7+3);
                    p4 =   Cube( Type*5+i ,16+j*7+4);
                    P4 = [obj.P(p1,:)',obj.P(p2,:)',obj.P(p3,:)',obj.P(p4,:)',obj.P(p1,:)'];
                      plot3(P4(1,:),P4(2,:),P4(3,:),'Color',color);
                    case 5
                    p1 =   Cube( Type*5+i ,16+j*7+1);
                    p2 =   Cube( Type*5+i ,16+j*7+2);
                    p3 =   Cube( Type*5+i ,16+j*7+3);
                    p4 =   Cube( Type*5+i ,16+j*7+4);
                    p5 =   Cube( Type*5+i ,16+j*7+5);
                    P5 = [obj.P(p1,:)',obj.P(p2,:)',obj.P(p3,:)',obj.P(p4,:)',obj.P(p5,:)',obj.P(p1,:)'];
                      plot3(P5(1,:),P5(2,:),P5(3,:),'Color',color);

                    case 6
                    p1 =   Cube( Type*5+i ,16+j*7+1);
                    p2 =   Cube( Type*5+i ,16+j*7+2);
                    p3 =   Cube( Type*5+i ,16+j*7+3);
                    p4 =   Cube( Type*5+i ,16+j*7+4);
                    p5 =   Cube( Type*5+i ,16+j*7+5);
                    p6 =   Cube( Type*5+i ,16+j*7+6);

                     P6 = [obj.P(p1,:)',obj.P(p2,:)',obj.P(p3,:)',obj.P(p4,:)',obj.P(p5,:)',obj.P(p6,:)',obj.P(p1,:)'];

                     plot3(P6(1,:),P6(2,:),P6(3,:),'Color',color);
                end
                 end
            end

            hold off;
        end
    end


    methods(Static)
%         function DrawPolygon( PolygonCornerXY, color )
%             line( PolygonCornerXY(:,1), PolygonCornerXY(:,2), 'Color', color, 'LineWidth',2 );
%         end
        
%         function [Pts,W] = GetCartesianQuadrature_Box( CornerPtsXY, nPt )
%            
%            PtA = CornerPtsXY(1,:);
%            PtB = CornerPtsXY(2,:);
%            PtC = CornerPtsXY(3,:);
%            PtD = CornerPtsXY(4,:);
%            
%            a = PtA(1);
%            b = PtB(1);
%            c = PtA(2);
%            d = PtC(2);
%            
%            [Wx,X] = Cell_2D.Gauss_W_X_Scaled( a , b, nPt );
%            [Wy,Y] = Cell_2D.Gauss_W_X_Scaled( c , d, nPt );
%            
%            Pts = zeros(nPt*nPt,2);
%            W = zeros(nPt*nPt,1);
%            
%            count = 1;
%            for i = 1 : nPt
%                thisY = Y(i);
%                thisWy = Wy(i);
%                for j = 1 : nPt
%                    thisX = X(j);
%                    thisWx = Wx(j);
%                    Pts(count,:) = [thisX thisY];
%                    W(count) = thisWx * thisWy;
%                    count = count + 1;
%                end
%            end
%        end
       
    end
    
end

%          function Pts = GetRandomQuadraturePts_Boundary( obj, nPt, XYPolygon, nSamplingPts )
%             
%             XPoly = XYPolygon(:,1);
%             YPoly = XYPolygon(:,2);
%             
%             n = length(XPoly);
%             
%             
%             SamplingPts_PerEdge = ceil(nSamplingPts);
%             TestPts = [];
%             for i = 1 : n-1
%                 XY1 = [XPoly(i); YPoly(i)];
%                 XY2 = [XPoly(i+1); YPoly(i+1)];
%                 L = Cell_2D.GetEdgeLength(XY1,XY2);
%                 normal = Cell_2D.GetEdgeNormal(XY1,XY2);
%                 t = L / (SamplingPts_PerEdge-1);
%                 p = 0:t:L;
%                 Origin = repmat(XY1',length(p),1);
%                 n = repmat(normal,1,length(p));
%                 TestPts = [TestPts ;Origin + (n*diag(p))'];
%             end
%             XTestPts = TestPts(:,1); 
%             YTestPts = TestPts(:,2); 
% 
%             fVal = obj.m_PMC(XTestPts, YTestPts);
%             [m, n] = size( XTestPts);
%             X= reshape(XTestPts,[m*n,1]);
%             Y = reshape(YTestPts,[m*n,1]);
%             fVal = reshape(fVal,[m*n,1]);
% 
%             PassPtsX = X(fVal >0);
%             PassPtsY = Y(fVal >0);
% 
% %             [Index] = inpolygon( PassPtsX, PassPtsY, XPoly, YPoly);
% % 
% %             PassPtsX = PassPtsX(Index);
% %             PassPtsY = PassPtsY(Index);
% 
%             r = randperm(size(PassPtsX,1));
% 
%             PassPtsX = PassPtsX(r(1:nPt));
%             PassPtsY = PassPtsY(r(1:nPt));
%             Pts = [PassPtsX PassPtsY];
%          end
%         
%         function Pts = GetRandomQuadraturePts( obj, nPt, XYPolygon, nSamplingPts )
%             
%             XPoly = XYPolygon(:,1);
%             YPoly = XYPolygon(:,2);
%             BBox = obj.GetBoundingBox( XYPolygon );
%             StartPt = BBox(1,:);
%             EndPt = BBox(2,:);
%             hx = (EndPt - StartPt)/(nSamplingPts+1);
%             XTestPts = StartPt+hx:hx:EndPt-hx;
%             minY = obj.m_PointB(2);
%             maxY = obj.m_PointC(2);
%             hy = (maxY - minY)/(nSamplingPts+1);
%             YTestPts = minY + hy : hy : maxY - hy;
% 
%             [XTestPts, YTestPts] = meshgrid(XTestPts,YTestPts); 
% 
%             fVal = obj.m_PMC(XTestPts, YTestPts);
%             
%             nSmallFeatures = size(obj.m_SmallFeatureList,1);
% 
%             for i = 1 : nSmallFeatures
%                 if( i == 1 )
%                     fVal_Small_Features = ~obj.m_SmallFeatureList{i}.PMC(XTestPts,YTestPts);
%                 else
%                     fVal_Small_Features = and( fVal_Small_Features ,  ~obj.m_SmallFeatureList{i}.PMC(XTestPts,YTestPts));
%                 end
%                 
%             end
%             
%             [m, n] = size( XTestPts);
%             X= reshape(XTestPts,[m*n,1]);
%             Y = reshape(YTestPts,[m*n,1]);
%             fVal = reshape(fVal,[m*n,1]);
%             if( nSmallFeatures > 0 )
%                 fVal_Small_Features = reshape(fVal_Small_Features,[m*n,1]);
%                 fVal = and( fVal, fVal_Small_Features);
%             end
%             PassPtsX = X(fVal >0);
%             PassPtsY = Y(fVal >0);
% 
%             [Index] = inpolygon( PassPtsX, PassPtsY, XPoly, YPoly);
% 
%             PassPtsX = PassPtsX(Index);
%             PassPtsY = PassPtsY(Index);
% 
%             r = randperm(size(PassPtsX,1));
% 
%             PassPtsX = PassPtsX(r(1:nPt));
%             PassPtsY = PassPtsY(r(1:nPt));
%             Pts = [PassPtsX PassPtsY];
%         end
%         
%         function [XY,W] = GetQuadrature_AW( obj, polynomialDegree, distanceToBoundary, domainDegree  )
%             nPt = Cell_2D.GetNumberOfPoints_2D(polynomialDegree);
%             if( obj.IsInterior() )
%                 CornerPtsXY = [obj.m_PointA';obj.m_PointB'; obj.m_PointC'; obj.m_PointD'];
%                 numPts = ceil(sqrt(nPt));
%                 [XY,W] = Node_2D.GetCartesianQuadrature_Box( CornerPtsXY, numPts );
%             elseif( obj.IsBoundary() )
%                 nSamplingPts = 20*nPt;
%                 [ApproxPolygon, ComputeSSATerm] = obj.GetApproximatePolygon();
%                 XY = obj.GetRandomQuadraturePts( nPt, ApproxPolygon, nSamplingPts );
%                 thisCell = Cell_2D(ApproxPolygon, distanceToBoundary, domainDegree, true);
%                 W = thisCell.GetAdaptiveWeights( XY, polynomialDegree, ComputeSSATerm );
%                 
%                 nSmallFeatures = length(obj.m_SmallFeatureList);
%                 
%                 for i = 1 : nSmallFeatures
%                     [X,Y] = obj.m_SmallFeatureList{i}.Polygonize();
%                     ApproxPolygon = [X Y];
%                     ComputeSSATerm = obj.m_SmallFeatureList{i}.GetSSACorrection();
%                     dist = @(QP,Direction) obj.m_SmallFeatureList{i}.DistanceToBoundary(QP,Direction);
%                     AdaptiveQuadrature = true;
%                     domainDegree = obj.m_SmallFeatureList{i}.GetDomainDegree();
%                     thisCell = Cell_2D(ApproxPolygon, dist, domainDegree, AdaptiveQuadrature);
%                     W_f = thisCell.GetAdaptiveWeights( XY, polynomialDegree, ComputeSSATerm );
%                     W = W - W_f;
%                 end
%             else
%                 XY = [];
%                 W = [];
%             end
%         end
%         
%        
%          function [I, e, XY] = GetIntegral( obj, polynomialDegree, distanceToBoundary, domainDegree, integrand  )
%             nPt = Cell_2D.GetNumberOfPoints_2D(polynomialDegree);
%             if( obj.IsInterior() )
%                 CornerPtsXY = [obj.m_PointA';obj.m_PointB'; obj.m_PointC'; obj.m_PointD'];
%                 numPts = ceil(sqrt(nPt));
%                 [XY,W] = Node_2D.GetCartesianQuadrature_Box( CornerPtsXY, numPts );
%                 I = integrand(XY(:,1),XY(:,2))'*W;
%                 e = 0;
%             elseif( obj.IsBoundary() )
%                 nSamplingPts = 10*nPt;
%                 [ApproxPolygon, ComputeSSATerm] = obj.GetApproximatePolygon();
%                 polygonArea = abs(polyarea(ApproxPolygon(1:end-1,1), ApproxPolygon(1:end-1,2))) ;
%                 if( polygonArea < 1e-5)
%                     e = 0;
%                     I = polygonArea;
%                     XY = [];
%                 else
%                 XY = obj.GetRandomQuadraturePts( nPt, ApproxPolygon, nSamplingPts );
%                 %XY = obj.GetRandomQuadraturePts_Boundary(nPt, ApproxPolygon, nSamplingPts );
%                 thisCell = Cell_2D(ApproxPolygon, distanceToBoundary, domainDegree, true);
%                 [I, e] = thisCell.GetIntegral( XY, polynomialDegree, ComputeSSATerm, integrand, obj.m_SmallFeatureList );
%                 end
%             else
%                 I = 0;
%                 e = 0;
%             end
%             obj.m_Integral = I;
%             obj.m_Error = e;
%         end
%         
